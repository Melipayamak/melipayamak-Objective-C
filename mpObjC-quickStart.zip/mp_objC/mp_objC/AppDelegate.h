//
//  AppDelegate.h
//  mp_objC
//
//  Created by Amirhossein Mehrvarzi on 4/24/18.
//  Copyright © 2018 Amirhossein Mehrvarzi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

