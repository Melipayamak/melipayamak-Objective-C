//
//  ViewController.m
//  mp_objC
//
//  Created by Amirhossein Mehrvarzi on 4/24/18.
//  Copyright © 2018 Amirhossein Mehrvarzi. All rights reserved.
//

#import "ViewController.h"
#import "SoapClient.h"
#import "RestClient.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
//    SoapClient *soapclient = [[SoapClient alloc] initCred:@"9122088891" password:@"1234"];
//    [soapclient SendSimpleSMS2:@"09103155711" sender:@"500010604095" msg:@"iOS objective-C Soap TEST" flash:false];
    
    NSString *username = @"username";
    NSString *password = @"password";
    NSString *to = @"09123456789";
    NSString *from = @"5000...";
    NSString *message = @"iOS objective-C Soap TEST";
    BOOL isFlash = false;
    SoapClient *soapClient = [[SoapClient alloc] initCred:username password:password];
    [soapClient SendSimpleSMS2:to from:from msg:message flash:isFlash];
    
//    RestClient *restclient = [[RestClient alloc] initCred:username password:password];
//    [restclient Send:to sender:from msg:message flash:isFlash];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
