//
//  main.m
//  mp_objC
//
//  Created by Amirhossein Mehrvarzi on 4/24/18.
//  Copyright © 2018 Amirhossein Mehrvarzi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
